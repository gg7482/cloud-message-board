# cloudmsgboard

a simple could message board
you can leave message to others online and others will see them later

study goals
1. learn django framework
2. learn ajax asynchronous framework
3. review javascript and jquery